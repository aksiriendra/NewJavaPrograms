package com.example.mysqlspringdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySqlSpringDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
