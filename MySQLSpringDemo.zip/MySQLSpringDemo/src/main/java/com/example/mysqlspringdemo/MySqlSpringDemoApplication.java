package com.example.mysqlspringdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySqlSpringDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MySqlSpringDemoApplication.class, args);
    }

}
